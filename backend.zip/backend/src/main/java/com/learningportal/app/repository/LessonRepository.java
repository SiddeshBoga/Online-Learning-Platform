package com.learningportal.app.repository;

import com.learningportal.app.entity.Lesson;
import com.learningportal.app.entity.Course;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface LessonRepository extends JpaRepository<Lesson, Long> {
    List<Lesson> findByCourseOrderByOrderIndex(Course course);
}
