package com.learningportal.app.controller;

import com.learningportal.app.dto.CourseRequest;
import com.learningportal.app.entity.Course;
import com.learningportal.app.entity.Lesson;
import com.learningportal.app.service.CourseService;
import com.learningportal.app.service.LessonService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/courses")
@RequiredArgsConstructor
public class CourseController {

    private final CourseService courseService;
    private final LessonService lessonService;

    @GetMapping
    public ResponseEntity<List<Course>> getAll(@RequestParam(required = false) String search) {
        if (search != null && !search.isBlank())
            return ResponseEntity.ok(courseService.searchCourses(search));
        return ResponseEntity.ok(courseService.getAllCourses());
    }

    @GetMapping("/{id}")
    public ResponseEntity<Course> getById(@PathVariable Long id) {
        return ResponseEntity.ok(courseService.getCourseById(id));
    }

    @GetMapping("/{id}/lessons")
    public ResponseEntity<List<Lesson>> getLessons(@PathVariable Long id) {
        return ResponseEntity.ok(lessonService.getLessonsByCourse(id));
    }
}
