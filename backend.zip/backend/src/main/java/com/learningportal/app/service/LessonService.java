package com.learningportal.app.service;

import com.learningportal.app.dto.LessonRequest;
import com.learningportal.app.entity.Course;
import com.learningportal.app.entity.Lesson;
import com.learningportal.app.repository.CourseRepository;
import com.learningportal.app.repository.LessonRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@RequiredArgsConstructor
public class LessonService {

    private final LessonRepository lessonRepository;
    private final CourseRepository courseRepository;

    public Lesson addLesson(Long courseId, LessonRequest req) {
        Course course = courseRepository.findById(courseId).orElseThrow(() -> new RuntimeException("Course not found"));
        Lesson lesson = Lesson.builder()
                .title(req.getTitle())
                .content(req.getContent())
                .orderIndex(req.getOrderIndex())
                .course(course)
                .build();
        return lessonRepository.save(lesson);
    }

    public List<Lesson> getLessonsByCourse(Long courseId) {
        Course course = courseRepository.findById(courseId).orElseThrow();
        return lessonRepository.findByCourseOrderByOrderIndex(course);
    }

    public void deleteLesson(Long lessonId) {
        lessonRepository.deleteById(lessonId);
    }
}
