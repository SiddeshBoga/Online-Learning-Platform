package com.learningportal.app.service;

import com.learningportal.app.entity.*;
import com.learningportal.app.repository.*;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;

@Service
@RequiredArgsConstructor
public class EnrollmentService {

    private final EnrollmentRepository enrollmentRepository;
    private final UserRepository userRepository;
    private final CourseRepository courseRepository;

    public Enrollment enroll(String learnerEmail, Long courseId) {
        User learner = userRepository.findByEmail(learnerEmail).orElseThrow();
        Course course = courseRepository.findById(courseId).orElseThrow(() -> new RuntimeException("Course not found"));

        if (enrollmentRepository.existsByLearnerAndCourse(learner, course))
            throw new RuntimeException("Already enrolled");

        Enrollment enrollment = Enrollment.builder()
                .learner(learner)
                .course(course)
                .build();
        return enrollmentRepository.save(enrollment);
    }

    public Enrollment completeCourse(String learnerEmail, Long courseId) {
        User learner = userRepository.findByEmail(learnerEmail).orElseThrow();
        Course course = courseRepository.findById(courseId).orElseThrow();
        Enrollment enrollment = enrollmentRepository.findByLearnerAndCourse(learner, course)
                .orElseThrow(() -> new RuntimeException("Not enrolled in this course"));
        enrollment.setStatus(Enrollment.Status.COMPLETED);
        enrollment.setCompletedAt(LocalDateTime.now());
        return enrollmentRepository.save(enrollment);
    }

    public List<Enrollment> getMyEnrollments(String learnerEmail) {
        User learner = userRepository.findByEmail(learnerEmail).orElseThrow();
        return enrollmentRepository.findByLearner(learner);
    }

    public List<Enrollment> getEnrollmentsByCourse(Long courseId) {
        Course course = courseRepository.findById(courseId).orElseThrow();
        return enrollmentRepository.findByCourse(course);
    }

    public List<Enrollment> getAllEnrollments() {
        return enrollmentRepository.findAll();
    }
}
