package com.learningportal.app.dto;

import lombok.Data;

@Data
public class LessonRequest {
    private String title;
    private String content;
    private Integer orderIndex;
}
