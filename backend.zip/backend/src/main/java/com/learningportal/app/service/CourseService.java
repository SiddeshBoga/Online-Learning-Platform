package com.learningportal.app.service;

import com.learningportal.app.dto.CourseRequest;
import com.learningportal.app.entity.Course;
import com.learningportal.app.entity.User;
import com.learningportal.app.repository.CourseRepository;
import com.learningportal.app.repository.UserRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@RequiredArgsConstructor
public class CourseService {

    private final CourseRepository courseRepository;
    private final UserRepository userRepository;

    public List<Course> getAllCourses() {
        return courseRepository.findAll();
    }

    public Course getCourseById(Long id) {
        return courseRepository.findById(id).orElseThrow(() -> new RuntimeException("Course not found"));
    }

    public List<Course> searchCourses(String keyword) {
        return courseRepository.findByTitleContainingIgnoreCase(keyword);
    }

    public Course createCourse(CourseRequest req, String instructorEmail) {
        User instructor = userRepository.findByEmail(instructorEmail).orElseThrow();
        Course course = Course.builder()
                .title(req.getTitle())
                .description(req.getDescription())
                .category(req.getCategory())
                .level(req.getLevel())
                .instructor(instructor)
                .build();
        return courseRepository.save(course);
    }

    public Course updateCourse(Long id, CourseRequest req, String instructorEmail) {
        Course course = getCourseById(id);
        if (!course.getInstructor().getEmail().equals(instructorEmail))
            throw new RuntimeException("Not authorized to update this course");
        course.setTitle(req.getTitle());
        course.setDescription(req.getDescription());
        course.setCategory(req.getCategory());
        course.setLevel(req.getLevel());
        return courseRepository.save(course);
    }

    public void deleteCourse(Long id) {
        courseRepository.deleteById(id);
    }

    public List<Course> getCoursesByInstructor(String email) {
        User instructor = userRepository.findByEmail(email).orElseThrow();
        return courseRepository.findByInstructor(instructor);
    }
}
