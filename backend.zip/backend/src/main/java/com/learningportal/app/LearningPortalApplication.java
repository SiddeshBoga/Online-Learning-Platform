package com.learningportal.app;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LearningPortalApplication {
    public static void main(String[] args) {
        SpringApplication.run(LearningPortalApplication.class, args);
    }
}
