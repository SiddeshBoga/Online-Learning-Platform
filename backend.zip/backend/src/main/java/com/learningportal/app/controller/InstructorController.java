package com.learningportal.app.controller;

import com.learningportal.app.dto.*;
import com.learningportal.app.entity.*;
import com.learningportal.app.service.*;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/instructor")
@RequiredArgsConstructor
public class InstructorController {

    private final CourseService courseService;
    private final LessonService lessonService;
    private final EnrollmentService enrollmentService;

    @GetMapping("/courses")
    public ResponseEntity<List<Course>> myCourses(@AuthenticationPrincipal UserDetails user) {
        return ResponseEntity.ok(courseService.getCoursesByInstructor(user.getUsername()));
    }

    @PostMapping("/courses")
    public ResponseEntity<Course> createCourse(@RequestBody CourseRequest req,
                                               @AuthenticationPrincipal UserDetails user) {
        return ResponseEntity.ok(courseService.createCourse(req, user.getUsername()));
    }

    @PutMapping("/courses/{id}")
    public ResponseEntity<Course> updateCourse(@PathVariable Long id,
                                               @RequestBody CourseRequest req,
                                               @AuthenticationPrincipal UserDetails user) {
        return ResponseEntity.ok(courseService.updateCourse(id, req, user.getUsername()));
    }

    @DeleteMapping("/courses/{id}")
    public ResponseEntity<Void> deleteCourse(@PathVariable Long id) {
        courseService.deleteCourse(id);
        return ResponseEntity.noContent().build();
    }

    @PostMapping("/courses/{courseId}/lessons")
    public ResponseEntity<Lesson> addLesson(@PathVariable Long courseId,
                                            @RequestBody LessonRequest req) {
        return ResponseEntity.ok(lessonService.addLesson(courseId, req));
    }

    @DeleteMapping("/lessons/{lessonId}")
    public ResponseEntity<Void> deleteLesson(@PathVariable Long lessonId) {
        lessonService.deleteLesson(lessonId);
        return ResponseEntity.noContent().build();
    }

    @GetMapping("/courses/{courseId}/enrollments")
    public ResponseEntity<List<Enrollment>> courseEnrollments(@PathVariable Long courseId) {
        return ResponseEntity.ok(enrollmentService.getEnrollmentsByCourse(courseId));
    }
}
