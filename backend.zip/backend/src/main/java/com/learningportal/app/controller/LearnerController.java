package com.learningportal.app.controller;

import com.learningportal.app.entity.Enrollment;
import com.learningportal.app.service.EnrollmentService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/learner")
@RequiredArgsConstructor
public class LearnerController {

    private final EnrollmentService enrollmentService;

    @PostMapping("/enroll/{courseId}")
    public ResponseEntity<Enrollment> enroll(@PathVariable Long courseId,
                                             @AuthenticationPrincipal UserDetails user) {
        return ResponseEntity.ok(enrollmentService.enroll(user.getUsername(), courseId));
    }

    @PutMapping("/complete/{courseId}")
    public ResponseEntity<Enrollment> complete(@PathVariable Long courseId,
                                               @AuthenticationPrincipal UserDetails user) {
        return ResponseEntity.ok(enrollmentService.completeCourse(user.getUsername(), courseId));
    }

    @GetMapping("/my-courses")
    public ResponseEntity<List<Enrollment>> myCourses(@AuthenticationPrincipal UserDetails user) {
        return ResponseEntity.ok(enrollmentService.getMyEnrollments(user.getUsername()));
    }
}
